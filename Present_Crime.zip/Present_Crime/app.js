document.getElementById('button1').addEventListener('click', getRandom);

//Random number generator to cycle between crimes in api.

const random = Math.floor(Math.random() * 50000 + 1);
console.log(random);

// Pull API and show random crime
// Outputs in <li> by calling specific properties of the api object. Api url has random variable as an offset to pull different crime every time. Page has to be refreshed to get another crime.
function getRandom() {
  fetch(
    `https://data.brla.gov/resource/5rji-ddnu.json?$limit=1&$offset=${random}&$select=address,%20crime,%20district,%20offense_date,%20offense_desc,%20geolocation`
  )
    .then(function(res) {
      return res.json();
    })
    .then(function(data) {
      console.log(data);
      let output = '';
      data.forEach(function(id) {
        output = `<li> Address: ${id.address}</li><li> Crime: ${
          id.crime
        }</li><li> District: ${id.district}</li><li>Offense Date: ${
          id.offense_date
        }</li><li>Offense Description: ${
          id.offense_desc
        }</li><li> Geolocation: ${id.geolocation.coordinates}</li>`;
      });
      document.getElementById('output').innerHTML = output;
    })
    .catch(function(err) {
      console.log(err);
    });
}

// Query API for crime with street name
//Trying to create search function here where newText, the text in the search bar is added to api url to give randomized crime of a given street name. Believe I messed up when adding the promise into the Jquery. Additionally the keyup function is done at one time, meaning the search must be copied and pasted into search bar to get correct newText. See console.log.
$('.chatinput').keyup(function(event) {
  newText = event.target.value;
  $('.printchatbox').text(newText);
  console.log(newText);
  function search(newText) {
    fetch(
      `https://data.brla.gov/resource/5rji-ddnu.json?st_name=${newText}$limit=1&$offset=${random}&$select=address,%20crime,%20district,%20offense_date,%20offense_desc,%20geolocation`
    )
      .then(function(res) {
        return res.json();
      })
      .then(function(data) {
        console.log(data);
        let output = '';
        data.forEach(function(id) {
          output = `<li> Address: ${id.address}</li><li> Crime: ${
            id.crime
          }</li><li> District: ${id.district}</li><li>Offense Date: ${
            id.offense_date
          }</li><li>Offense Description: ${
            id.offense_desc
          }</li><li> Geolocation: ${id.geolocation.coordinates}</li>`;
        });
        document.getElementById('output').innerHTML = output;
      })
      .catch(function(err) {
        console.log(err);
      });
  }
});

function initMap() {
  // Styles a map in night mode.
  // Google map api key inserted into src in index.html.
  var map = new google.maps.Map(document.getElementById('map'), {
    center: { lat: 30.4515, lng: -91.1871 },
    zoom: 11,
    styles: [
      { elementType: 'geometry', stylers: [{ color: '#242f3e' }] },
      { elementType: 'labels.text.stroke', stylers: [{ color: '#242f3e' }] },
      { elementType: 'labels.text.fill', stylers: [{ color: '#746855' }] },
      {
        featureType: 'administrative.locality',
        elementType: 'labels.text.fill',
        stylers: [{ color: '#d59563' }]
      },
      {
        featureType: 'poi',
        elementType: 'labels.text.fill',
        stylers: [{ color: '#d59563' }]
      },
      {
        featureType: 'poi.park',
        elementType: 'geometry',
        stylers: [{ color: '#263c3f' }]
      },
      {
        featureType: 'poi.park',
        elementType: 'labels.text.fill',
        stylers: [{ color: '#6b9a76' }]
      },
      {
        featureType: 'road',
        elementType: 'geometry',
        stylers: [{ color: '#38414e' }]
      },
      {
        featureType: 'road',
        elementType: 'geometry.stroke',
        stylers: [{ color: '#212a37' }]
      },
      {
        featureType: 'road',
        elementType: 'labels.text.fill',
        stylers: [{ color: '#9ca5b3' }]
      },
      {
        featureType: 'road.highway',
        elementType: 'geometry',
        stylers: [{ color: '#746855' }]
      },
      {
        featureType: 'road.highway',
        elementType: 'geometry.stroke',
        stylers: [{ color: '#1f2835' }]
      },
      {
        featureType: 'road.highway',
        elementType: 'labels.text.fill',
        stylers: [{ color: '#f3d19c' }]
      },
      {
        featureType: 'transit',
        elementType: 'geometry',
        stylers: [{ color: '#2f3948' }]
      },
      {
        featureType: 'transit.station',
        elementType: 'labels.text.fill',
        stylers: [{ color: '#d59563' }]
      },
      {
        featureType: 'water',
        elementType: 'geometry',
        stylers: [{ color: '#17263c' }]
      },
      {
        featureType: 'water',
        elementType: 'labels.text.fill',
        stylers: [{ color: '#515c6d' }]
      },
      {
        featureType: 'water',
        elementType: 'labels.text.stroke',
        stylers: [{ color: '#17263c' }]
      }
    ]
  });
}

document.getElementById('button1').addEventListener('click', makePin);

//Trying to make a pin drop onto Google map by calling the geolocation coordinates I get from the random crime promise. The pin would also have the title of the crime. The pin works when I put in predetermined lat/lng and nest it into the map above (see Notes.txt for functinal pin drop). However it breaks the map if I have id.x while nested. I believe this to be some form of scope issue.
function makePin(id) {
  var marker = new google.maps.Marker({
    position: {
      lat: `${id.geolocation.coordinates[1]}`,
      lng: `${id.geolocation.coordinates[0]}`
    },
    map: map,
    title: `${id.crime}`
  });
}

// An alternative thought to the search issue. #button2 is the search button apended to the search bar in navbar.
document.getElementById('button2').addEventListener('click', startSearch);
